#!/usr/bin/env python


import sys
import os
import re

a=sys.argv[1]

f=open(a,'r')

listF = f.readlines()
f.close()
annot = dict
c = 0
k = list()
for line in listF:
	h = line.strip("\n").strip('\r').split('\t')[0:2]
	k = [ x.replace("\"","") for x in h[1].split("+")]
	for x in k:
		print x + "\t" + h[0]
